<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class Model extends CI_Model
{
    
}
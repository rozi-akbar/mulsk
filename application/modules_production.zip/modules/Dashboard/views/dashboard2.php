<div class="page-content-wrapper py-3">
    <div class="container">
        <!-- Element Heading-->
        <h6 style="text-align: center;">Pesanan/Order</h6>
    </div>
    <div class="container">
        <div class="row">
            <div class="col-6">
                <div class="card">
                    <a href="<?=base_url()?>Order/Create_order">
                        <div class="card-body">
                            Buat Pesanan
                        </div>
                    </a>
                </div>
            </div>
            <div class="col-6">
                <div class="card">
                    <div class="card-body">
                        Riwayat Pesanan
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
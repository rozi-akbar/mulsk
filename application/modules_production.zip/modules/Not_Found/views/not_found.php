<div id="nt_content">
    <div class="empty_cart_page tc bg-img">
        <div class="container">
            <section class="error-404 not-found">
                <div>
                    <h1>404</h1>
                    <h3 class="page-title">Sorry! Page you are looking can’t be found.</h3>
                    <p>Go back to the <a href="<?= base_url() ?>" rel="home">homepage</a></p>
                </div>
            </section>
        </div>
    </div>
</div>
<style>
    .bg-img {
        background-image: url('<?= base_url() ?>assets/images/bg-404-mulsk.jpg');
        background-position: center;
        background-repeat: no-repeat;
        background-size: contain;
    }
</style>